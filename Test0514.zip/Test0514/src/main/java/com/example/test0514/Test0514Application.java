package com.example.test0514;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test0514Application {

    public static void main(String[] args) {
        SpringApplication.run(Test0514Application.class, args);
    }

}
